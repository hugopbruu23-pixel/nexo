import { Download } from "lucide-react";
import { useState } from "react";
import JSZip from "jszip";
import { saveAs } from "file-saver";

interface ProjectFile {
  path: string;
  content: string;
}

interface ProjectDownloaderProps {
  content: string;
}

/**
 * Extracts multiple code blocks with file paths from AI response and offers ZIP download
 */
export function ProjectDownloader({ content }: ProjectDownloaderProps) {
  const [downloading, setDownloading] = useState(false);

  const files = extractProjectFiles(content);
  if (files.length < 2) return null;

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      files.forEach((f) => zip.file(f.path, f.content));
      const blob = await zip.generateAsync({ type: "blob" });
      saveAs(blob, "nexo-project.zip");
    } catch (e) {
      console.error("Failed to create ZIP:", e);
    }
    setDownloading(false);
  };

  return (
    <button
      onClick={handleDownload}
      disabled={downloading}
      className="inline-flex items-center gap-2 mt-3 px-4 py-2 rounded-lg bg-primary/15 text-primary border border-primary/20 hover:bg-primary/25 transition-colors text-sm font-medium disabled:opacity-50"
    >
      <Download className="h-4 w-4" />
      {downloading ? "Gerando ZIP..." : `Baixar projeto (${files.length} arquivos)`}
    </button>
  );
}

function extractProjectFiles(content: string): ProjectFile[] {
  const files: ProjectFile[] = [];
  // Match patterns like ```filename.ext or ```lang:filename.ext or // filename.ext at first line
  const codeBlockRegex = /```(\w*?)(?::?([\w./\-]+\.\w+))?\n([\s\S]*?)```/g;

  let match;
  while ((match = codeBlockRegex.exec(content)) !== null) {
    const lang = match[1];
    let path = match[2];
    const code = match[3].trim();

    if (!path) {
      // Try to extract filename from first line comment
      const firstLine = code.split("\n")[0];
      const commentMatch = firstLine.match(/(?:\/\/|#|<!--)\s*([\w./\-]+\.\w+)/);
      if (commentMatch) {
        path = commentMatch[1];
      }
    }

    if (path) {
      files.push({ path, content: code });
    }
  }

  return files;
}
