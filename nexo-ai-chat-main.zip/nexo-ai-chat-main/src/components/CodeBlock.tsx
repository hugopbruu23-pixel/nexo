import { useState } from "react";
import { Copy, Check, Download } from "lucide-react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";

interface CodeBlockProps {
  language?: string;
  children: string;
}

export function CodeBlock({ language, children }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(children);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const ext = getExtension(language);
    const blob = new Blob([children], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `code.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="relative group rounded-lg overflow-hidden border border-border my-3">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-[hsl(220,14%,12%)] border-b border-border">
        <span className="text-xs text-muted-foreground font-mono">{language || "code"}</span>
        <div className="flex gap-1">
          <button
            onClick={handleDownload}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100"
            title="Download"
          >
            <Download className="h-3.5 w-3.5" />
          </button>
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100"
            title="Copiar"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
        </div>
      </div>
      <SyntaxHighlighter
        language={language || "text"}
        style={oneDark}
        customStyle={{
          margin: 0,
          padding: "1rem",
          background: "hsl(220, 14%, 10%)",
          fontSize: "0.8rem",
          borderRadius: 0,
        }}
        wrapLongLines
      >
        {children}
      </SyntaxHighlighter>
    </div>
  );
}

function getExtension(lang?: string): string {
  const map: Record<string, string> = {
    javascript: "js", typescript: "ts", python: "py", html: "html", css: "css",
    json: "json", jsx: "jsx", tsx: "tsx", bash: "sh", shell: "sh", sql: "sql",
    markdown: "md", yaml: "yaml", xml: "xml", rust: "rs", go: "go", java: "java",
    cpp: "cpp", c: "c", php: "php", ruby: "rb", swift: "swift", kotlin: "kt",
  };
  return map[lang || ""] || "txt";
}
