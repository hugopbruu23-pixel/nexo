import { motion } from "framer-motion";

interface NexoLogoProps {
  size?: "sm" | "md" | "lg";
  animate?: boolean;
}

const sizes = {
  sm: "h-6 w-6",
  md: "h-8 w-8",
  lg: "h-12 w-12",
};

const textSizes = {
  sm: "text-lg",
  md: "text-xl",
  lg: "text-3xl",
};

export function NexoLogo({ size = "md", animate = true }: NexoLogoProps) {
  const Container = animate ? motion.div : "div";

  return (
    <div className="flex items-center gap-2.5">
      <Container
        className="relative"
        {...(animate && {
          initial: { scale: 0.8, opacity: 0 },
          animate: { scale: 1, opacity: 1 },
          transition: { duration: 0.5, ease: "easeOut" },
        })}
      >
        <div className={`${sizes[size]} rounded-lg bg-primary/20 flex items-center justify-center relative`}>
          <div className="absolute inset-0 rounded-lg animate-pulse-ring bg-primary/10" />
          <svg
            viewBox="0 0 24 24"
            fill="none"
            className={`${size === "sm" ? "h-3.5 w-3.5" : size === "md" ? "h-4.5 w-4.5" : "h-7 w-7"}`}
          >
            <path
              d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
              stroke="hsl(175, 70%, 50%)"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </Container>
      <span className={`${textSizes[size]} font-semibold tracking-tight nexo-gradient-text`}>
        Nexo
      </span>
    </div>
  );
}
