import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus, MessageSquare, Trash2, PanelLeftClose, PanelLeft,
  Sparkles, Code, Image, FileText, Globe, Mic, Video,
  Settings, Zap, Brain, Search, BookOpen, Terminal,
  Palette, Shield, ChevronDown, ChevronRight, Download,
  Languages, BarChart3, Wand2
} from "lucide-react";
import { NexoLogo } from "./NexoLogo";

export interface Conversation {
  id: string;
  title: string;
  createdAt: Date;
}

interface ToolItem {
  icon: React.ElementType;
  label: string;
  description: string;
  tag?: string;
}

const aiCapabilities: ToolItem[] = [
  { icon: Code, label: "Gerador de Código", description: "Sites, apps e projetos completos", tag: "Pro" },
  { icon: Globe, label: "Web Completa", description: "Frontend + Backend + Deploy" },
  { icon: Terminal, label: "CLI & Scripts", description: "Automações e scripts de terminal" },
  { icon: Image, label: "Análise de Imagem", description: "Descrever, editar e criar imagens", tag: "AI" },
  { icon: FileText, label: "Análise de Documentos", description: "PDF, DOC, planilhas e mais" },
  { icon: Video, label: "Análise de Vídeo", description: "Processar e analisar vídeos", tag: "AI" },
  { icon: Mic, label: "Áudio & Voz", description: "Transcrição e análise de áudio", tag: "AI" },
  { icon: Languages, label: "Tradução", description: "Traduza para qualquer idioma" },
  { icon: BarChart3, label: "Análise de Dados", description: "Gráficos, estatísticas e insights" },
  { icon: Palette, label: "UI/UX Design", description: "Protótipos e design systems" },
  { icon: Brain, label: "Raciocínio Avançado", description: "Lógica complexa e planejamento", tag: "Pro" },
  { icon: Wand2, label: "Criativo", description: "Textos, nomes, slogans e ideias" },
];

const quickActions: { icon: React.ElementType; label: string; prompt: string }[] = [
  { icon: Code, label: "Criar site", prompt: "Crie um site completo e moderno com React e Tailwind CSS" },
  { icon: Sparkles, label: "Gerar app", prompt: "Gere um aplicativo completo com todas as funcionalidades necessárias" },
  { icon: Download, label: "Gerar projeto ZIP", prompt: "Gere um projeto completo e organize os arquivos para download em ZIP" },
  { icon: Search, label: "Analisar código", prompt: "Analise este código e sugira melhorias de performance e boas práticas" },
  { icon: BookOpen, label: "Explicar conceito", prompt: "Explique de forma clara e didática o seguinte conceito:" },
  { icon: Shield, label: "Review de segurança", prompt: "Faça uma revisão de segurança completa deste código e identifique vulnerabilidades" },
];

interface ChatSidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  onQuickAction?: (prompt: string) => void;
}

export function ChatSidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
  isOpen,
  onToggle,
  onQuickAction,
}: ChatSidebarProps) {
  const [showCapabilities, setShowCapabilities] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredConvs = conversations.filter((c) =>
    c.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      {!isOpen && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={onToggle}
          className="fixed top-3 left-3 z-50 h-9 w-9 rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <PanelLeft className="h-4 w-4" />
        </motion.button>
      )}

      <AnimatePresence>
        {isOpen && (
          <motion.aside
            initial={{ x: -300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="w-[300px] h-screen flex flex-col bg-sidebar border-r border-sidebar-border shrink-0 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-3 border-b border-sidebar-border">
              <NexoLogo size="sm" animate={false} />
              <div className="flex items-center gap-1">
                <button
                  onClick={onNew}
                  className="h-8 w-8 rounded-lg flex items-center justify-center text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
                  title="Nova conversa"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <button
                  onClick={onToggle}
                  className="h-8 w-8 rounded-lg flex items-center justify-center text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
                >
                  <PanelLeftClose className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Search */}
            <div className="px-3 pt-3 pb-1">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Buscar conversas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full h-8 pl-8 pr-3 rounded-lg bg-sidebar-accent/50 border border-sidebar-border text-xs text-sidebar-foreground placeholder:text-muted-foreground outline-none focus:border-primary/40 transition-colors"
                />
              </div>
            </div>

            {/* Quick Actions */}
            <div className="px-2 pt-2">
              <button
                onClick={() => setShowQuickActions(!showQuickActions)}
                className="flex items-center gap-1.5 px-2 py-1.5 w-full text-xs font-medium text-muted-foreground hover:text-sidebar-foreground transition-colors"
              >
                {showQuickActions ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                <Zap className="h-3 w-3 text-primary" />
                Ações Rápidas
              </button>
              <AnimatePresence>
                {showQuickActions && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="grid grid-cols-2 gap-1 p-1">
                      {quickActions.map((action, i) => (
                        <button
                          key={i}
                          onClick={() => onQuickAction?.(action.prompt)}
                          className="flex items-center gap-1.5 px-2 py-2 rounded-lg text-[11px] text-sidebar-foreground hover:bg-sidebar-accent transition-colors text-left"
                        >
                          <action.icon className="h-3.5 w-3.5 text-primary shrink-0" />
                          <span className="truncate">{action.label}</span>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* AI Capabilities */}
            <div className="px-2 pt-1">
              <button
                onClick={() => setShowCapabilities(!showCapabilities)}
                className="flex items-center gap-1.5 px-2 py-1.5 w-full text-xs font-medium text-muted-foreground hover:text-sidebar-foreground transition-colors"
              >
                {showCapabilities ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                <Brain className="h-3 w-3 text-primary" />
                Capacidades da IA
              </button>
              <AnimatePresence>
                {showCapabilities && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="space-y-0.5 p-1 max-h-[200px] overflow-y-auto">
                      {aiCapabilities.map((cap, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-sidebar-foreground"
                        >
                          <cap.icon className="h-3.5 w-3.5 text-primary shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] font-medium truncate">{cap.label}</span>
                              {cap.tag && (
                                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-primary/15 text-primary font-medium">
                                  {cap.tag}
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-muted-foreground truncate">{cap.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Divider */}
            <div className="px-3 pt-1 pb-0.5">
              <div className="h-px bg-sidebar-border" />
            </div>

            {/* Conversations header */}
            <div className="px-3 pt-1.5 pb-1">
              <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Conversas</span>
            </div>

            {/* Conversations */}
            <div className="flex-1 overflow-y-auto px-2 space-y-0.5 pb-2">
              <AnimatePresence>
                {filteredConvs.map((conv, i) => (
                  <motion.button
                    key={conv.id}
                    initial={{ opacity: 0, x: -12 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -12 }}
                    transition={{ delay: i * 0.02 }}
                    onClick={() => onSelect(conv.id)}
                    className={`group w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-left text-sm transition-colors ${
                      activeId === conv.id
                        ? "bg-sidebar-accent text-sidebar-accent-foreground"
                        : "text-sidebar-foreground hover:bg-sidebar-accent/50"
                    }`}
                  >
                    <MessageSquare className="h-3.5 w-3.5 shrink-0 opacity-50" />
                    <span className="truncate flex-1 text-xs">{conv.title}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(conv.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-destructive/20 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </motion.button>
                ))}
              </AnimatePresence>

              {filteredConvs.length === 0 && (
                <div className="px-3 py-6 text-center">
                  <MessageSquare className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-[11px] text-muted-foreground">
                    {searchTerm ? "Nenhuma conversa encontrada" : "Nenhuma conversa ainda"}
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-sidebar-border space-y-2">
              <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-sidebar-accent/30">
                <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center">
                  <Sparkles className="h-3 w-3 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-medium text-sidebar-foreground">Nexo AI</p>
                  <p className="text-[9px] text-muted-foreground">Gemini 3 Flash · Online</p>
                </div>
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              </div>
              <p className="text-[9px] text-muted-foreground text-center">Nexo AI — v2.0 · Todas capacidades ativas</p>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}
