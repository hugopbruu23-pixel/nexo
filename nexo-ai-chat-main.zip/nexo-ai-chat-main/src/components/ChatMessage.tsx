import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { User, Copy, Check, Image as ImageIcon, FileText } from "lucide-react";
import { useState } from "react";
import { CodeBlock } from "./CodeBlock";
import { ProjectDownloader } from "./ProjectDownloader";
import { FileAttachment } from "@/lib/chat-stream";

interface ChatMessageProps {
  role: "user" | "assistant";
  content: string;
  index: number;
  attachments?: FileAttachment[];
}

export function ChatMessage({ role, content, index, attachments }: ChatMessageProps) {
  const [copied, setCopied] = useState(false);
  const isUser = role === "user";

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: Math.min(index * 0.05, 0.2), ease: "easeOut" }}
      className={`group flex items-start gap-3 px-4 py-4 ${isUser ? "" : "bg-secondary/30"}`}
    >
      <div
        className={`h-7 w-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
          isUser ? "bg-muted" : "bg-primary/15"
        }`}
      >
        {isUser ? (
          <User className="h-4 w-4 text-muted-foreground" />
        ) : (
          <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4">
            <path
              d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
              stroke="hsl(175, 70%, 50%)"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </div>

      <div className="flex-1 min-w-0 space-y-1">
        <p className="text-xs font-medium text-muted-foreground">
          {isUser ? "Você" : "Nexo"}
        </p>

        {/* Attachment previews for user messages */}
        {isUser && attachments && attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-2">
            {attachments.map((att, i) =>
              att.preview ? (
                <div key={i} className="h-24 w-24 rounded-lg overflow-hidden border border-border">
                  <img src={att.preview} alt={att.name} className="h-full w-full object-cover" />
                </div>
              ) : (
                <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-secondary/50">
                  <FileText className="h-4 w-4 text-primary" />
                  <span className="text-xs text-foreground truncate max-w-[150px]">{att.name}</span>
                </div>
              )
            )}
          </div>
        )}

        <div className="prose prose-sm prose-invert max-w-none text-foreground leading-relaxed [&_a]:text-primary [&_a]:no-underline hover:[&_a]:underline [&_p]:my-1.5 [&_ul]:my-1.5 [&_ol]:my-1.5">
          <ReactMarkdown
            components={{
              code({ className, children, ...props }) {
                const match = /language-(\w+)/.exec(className || "");
                const codeString = String(children).replace(/\n$/, "");
                
                // Inline code
                if (!match && !codeString.includes("\n")) {
                  return (
                    <code className="px-1.5 py-0.5 rounded bg-[hsl(220,14%,16%)] text-primary font-mono text-xs" {...props}>
                      {children}
                    </code>
                  );
                }

                return <CodeBlock language={match?.[1]}>{codeString}</CodeBlock>;
              },
              pre({ children }) {
                return <>{children}</>;
              },
            }}
          >
            {content}
          </ReactMarkdown>
        </div>

        {/* Project downloader for multi-file responses */}
        {!isUser && content && <ProjectDownloader content={content} />}
      </div>

      {!isUser && content && (
        <button
          onClick={handleCopy}
          className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
        </button>
      )}
    </motion.div>
  );
}
