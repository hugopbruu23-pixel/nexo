import { motion } from "framer-motion";

export function ThinkingIndicator() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-start gap-3 px-4 py-3"
    >
      <div className="h-7 w-7 rounded-lg bg-primary/15 flex items-center justify-center shrink-0 mt-0.5">
        <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4">
          <path
            d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
            stroke="hsl(175, 70%, 50%)"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div className="flex items-center gap-1.5 pt-2">
        <div className="h-2 w-2 rounded-full bg-primary thinking-dot-1" />
        <div className="h-2 w-2 rounded-full bg-primary thinking-dot-2" />
        <div className="h-2 w-2 rounded-full bg-primary thinking-dot-3" />
        <span className="ml-2 text-sm text-muted-foreground">Nexo está pensando...</span>
      </div>
    </motion.div>
  );
}
