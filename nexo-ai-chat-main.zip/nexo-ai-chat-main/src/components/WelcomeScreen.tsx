import { motion } from "framer-motion";
import { Sparkles, Code, Globe, Lightbulb, Smartphone, Palette, Database, Gamepad2 } from "lucide-react";
import { NexoLogo } from "./NexoLogo";

interface WelcomeScreenProps {
  onSuggestionClick: (text: string) => void;
}

const suggestions = [
  { icon: Code, text: "Crie um site completo de portfólio com React e Tailwind" },
  { icon: Smartphone, text: "Gere um app de lista de tarefas com React Native" },
  { icon: Globe, text: "Crie uma API REST completa em Node.js com autenticação" },
  { icon: Database, text: "Monte um dashboard com gráficos e banco de dados" },
  { icon: Palette, text: "Desenhe um landing page moderna com animações" },
  { icon: Gamepad2, text: "Crie um jogo simples em JavaScript com canvas" },
  { icon: Lightbulb, text: "Me ajude a planejar a arquitetura de um SaaS" },
  { icon: Sparkles, text: "Analise esta imagem e me dê sugestões de melhoria" },
];

export function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-10"
      >
        <div className="flex justify-center mb-4">
          <NexoLogo size="lg" />
        </div>
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-muted-foreground text-base"
        >
          IA poderosa para criar, analisar e desenvolver qualquer coisa
        </motion.p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.4 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 max-w-4xl w-full"
      >
        {suggestions.map((s, i) => (
          <motion.button
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + i * 0.06 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSuggestionClick(s.text)}
            className="flex items-start gap-3 p-4 rounded-xl border border-border bg-secondary/30 hover:bg-secondary/60 hover:border-primary/20 transition-all text-left group"
          >
            <s.icon className="h-5 w-5 text-primary shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
            <span className="text-sm text-secondary-foreground">{s.text}</span>
          </motion.button>
        ))}
      </motion.div>
    </div>
  );
}
