import { useState, useRef, useEffect, useCallback } from "react";
import { ChatSidebar, Conversation } from "@/components/ChatSidebar";
import { ChatMessage } from "@/components/ChatMessage";
import { ChatInput } from "@/components/ChatInput";
import { ThinkingIndicator } from "@/components/ThinkingIndicator";
import { WelcomeScreen } from "@/components/WelcomeScreen";
import { streamChat, Msg, FileAttachment } from "@/lib/chat-stream";
import { toast } from "sonner";

interface ChatState {
  messages: Msg[];
}

const Index = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [chats, setChats] = useState<Record<string, ChatState>>({});
  const [isLoading, setIsLoading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeMessages = activeConvId ? chats[activeConvId]?.messages || [] : [];

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [activeMessages, isLoading, scrollToBottom]);

  const createConversation = (firstMessage?: string) => {
    const id = crypto.randomUUID();
    const title = firstMessage
      ? firstMessage.length > 40
        ? firstMessage.slice(0, 40) + "..."
        : firstMessage
      : "Nova conversa";
    const conv: Conversation = { id, title, createdAt: new Date() };
    setConversations((prev) => [conv, ...prev]);
    setChats((prev) => ({ ...prev, [id]: { messages: [] } }));
    setActiveConvId(id);
    return id;
  };

  const handleSend = async (input: string, attachments?: FileAttachment[]) => {
    let convId = activeConvId;
    if (!convId) {
      convId = createConversation(input || "Anexo");
    }

    const userMsg: Msg = {
      role: "user",
      content: input,
      attachments,
    };
    setChats((prev) => ({
      ...prev,
      [convId!]: {
        messages: [...(prev[convId!]?.messages || []), userMsg],
      },
    }));
    setIsLoading(true);

    // Update conversation title if first message
    if ((chats[convId]?.messages || []).length === 0) {
      const title = input || "Anexo";
      setConversations((prev) =>
        prev.map((c) =>
          c.id === convId
            ? { ...c, title: title.length > 40 ? title.slice(0, 40) + "..." : title }
            : c
        )
      );
    }

    const abortController = new AbortController();
    abortRef.current = abortController;

    let assistantSoFar = "";

    const upsertAssistant = (chunk: string) => {
      assistantSoFar += chunk;
      const finalContent = assistantSoFar;
      setChats((prev) => {
        const msgs = prev[convId!]?.messages || [];
        const last = msgs[msgs.length - 1];
        if (last?.role === "assistant") {
          return {
            ...prev,
            [convId!]: {
              messages: msgs.map((m, i) =>
                i === msgs.length - 1 ? { ...m, content: finalContent } : m
              ),
            },
          };
        }
        return {
          ...prev,
          [convId!]: {
            messages: [...msgs, { role: "assistant", content: finalContent }],
          },
        };
      });
    };

    try {
      const allMessages = [...(chats[convId]?.messages || []), userMsg];
      await streamChat({
        messages: allMessages,
        onDelta: upsertAssistant,
        onDone: () => setIsLoading(false),
        signal: abortController.signal,
      });
    } catch (e: any) {
      if (e.name !== "AbortError") {
        toast.error(e.message || "Erro ao se comunicar com o Nexo.");
      }
      setIsLoading(false);
    }
  };

  const handleStop = () => {
    abortRef.current?.abort();
    setIsLoading(false);
  };

  const handleNewChat = () => {
    setActiveConvId(null);
  };

  const handleDeleteConv = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    setChats((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    if (activeConvId === id) setActiveConvId(null);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <ChatSidebar
        conversations={conversations}
        activeId={activeConvId}
        onSelect={setActiveConvId}
        onNew={handleNewChat}
        onDelete={handleDeleteConv}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        onQuickAction={handleSend}
      />

      <div className="flex-1 flex flex-col min-w-0">
        {activeMessages.length === 0 && !isLoading ? (
          <>
            <WelcomeScreen onSuggestionClick={handleSend} />
            <ChatInput onSend={handleSend} onStop={handleStop} isLoading={isLoading} />
          </>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto">
              <div className="max-w-3xl mx-auto py-4">
                {activeMessages.map((msg, i) => (
                  <ChatMessage
                    key={i}
                    role={msg.role}
                    content={typeof msg.content === "string" ? msg.content : ""}
                    index={i}
                    attachments={msg.attachments}
                  />
                ))}
                {isLoading && activeMessages[activeMessages.length - 1]?.role === "user" && (
                  <ThinkingIndicator />
                )}
                <div ref={messagesEndRef} />
              </div>
            </div>
            <ChatInput onSend={handleSend} onStop={handleStop} isLoading={isLoading} />
          </>
        )}
      </div>
    </div>
  );
};

export default Index;
