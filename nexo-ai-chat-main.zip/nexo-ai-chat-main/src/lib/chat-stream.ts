const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/nexo-chat`;

export type ContentPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string } };

export type Msg = {
  role: "user" | "assistant";
  content: string | ContentPart[];
  attachments?: FileAttachment[];
};

export interface FileAttachment {
  name: string;
  type: string;
  size: number;
  dataUrl: string; // base64 data URL
  preview?: string; // for images
}

export async function streamChat({
  messages,
  onDelta,
  onDone,
  signal,
}: {
  messages: Msg[];
  onDelta: (deltaText: string) => void;
  onDone: () => void;
  signal?: AbortSignal;
}) {
  // Convert messages to API format - transform attachments to content parts
  const apiMessages = messages.map((msg) => {
    if (msg.role === "user" && msg.attachments && msg.attachments.length > 0) {
      const parts: ContentPart[] = [];
      
      // Add text content
      const textContent = typeof msg.content === "string" ? msg.content : "";
      if (textContent) {
        parts.push({ type: "text", text: textContent });
      }

      // Add image attachments as image_url parts
      for (const att of msg.attachments) {
        if (att.type.startsWith("image/")) {
          parts.push({
            type: "image_url",
            image_url: { url: att.dataUrl },
          });
        } else {
          // For non-image files, add as text description with content
          parts.push({
            type: "text",
            text: `[Arquivo anexado: ${att.name} (${att.type}, ${formatFileSize(att.size)})]`,
          });
        }
      }

      if (parts.length === 0) {
        parts.push({ type: "text", text: textContent || "" });
      }

      return { role: msg.role, content: parts };
    }

    return { role: msg.role, content: typeof msg.content === "string" ? msg.content : msg.content };
  });

  const resp = await fetch(CHAT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
    },
    body: JSON.stringify({ messages: apiMessages }),
    signal,
  });

  if (!resp.ok || !resp.body) {
    if (resp.status === 429) throw new Error("Limite de requisições atingido. Tente novamente em alguns segundos.");
    if (resp.status === 402) throw new Error("Créditos insuficientes. Adicione créditos ao seu workspace.");
    throw new Error("Falha ao conectar com o Nexo.");
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let textBuffer = "";
  let streamDone = false;

  while (!streamDone) {
    const { done, value } = await reader.read();
    if (done) break;
    textBuffer += decoder.decode(value, { stream: true });

    let newlineIndex: number;
    while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
      let line = textBuffer.slice(0, newlineIndex);
      textBuffer = textBuffer.slice(newlineIndex + 1);

      if (line.endsWith("\r")) line = line.slice(0, -1);
      if (line.startsWith(":") || line.trim() === "") continue;
      if (!line.startsWith("data: ")) continue;

      const jsonStr = line.slice(6).trim();
      if (jsonStr === "[DONE]") {
        streamDone = true;
        break;
      }

      try {
        const parsed = JSON.parse(jsonStr);
        const content = parsed.choices?.[0]?.delta?.content as string | undefined;
        if (content) onDelta(content);
      } catch {
        textBuffer = line + "\n" + textBuffer;
        break;
      }
    }
  }

  // Final flush
  if (textBuffer.trim()) {
    for (let raw of textBuffer.split("\n")) {
      if (!raw) continue;
      if (raw.endsWith("\r")) raw = raw.slice(0, -1);
      if (raw.startsWith(":") || raw.trim() === "") continue;
      if (!raw.startsWith("data: ")) continue;
      const jsonStr = raw.slice(6).trim();
      if (jsonStr === "[DONE]") continue;
      try {
        const parsed = JSON.parse(jsonStr);
        const content = parsed.choices?.[0]?.delta?.content as string | undefined;
        if (content) onDelta(content);
      } catch { /* ignore */ }
    }
  }

  onDone();
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}
