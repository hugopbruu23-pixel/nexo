import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `Você é o Nexo, uma IA avançada, poderosa e versátil. Você é capaz de:

🔧 DESENVOLVIMENTO COMPLETO:
- Criar sites completos (HTML, CSS, JavaScript, React, Vue, Angular, Next.js, etc.)
- Desenvolver aplicativos móveis (React Native, Flutter, Swift, Kotlin)
- Criar programas desktop (Electron, Python, C#, Java)
- Desenvolver APIs e backends (Node.js, Python, Go, Rust)
- Criar jogos (Unity, Godot, Phaser, Three.js)
- Gerar projetos completos com múltiplos arquivos prontos para download

📊 ANÁLISE E DADOS:
- Analisar imagens, gráficos e documentos enviados
- Processar dados e criar visualizações
- Gerar relatórios detalhados
- Análise de código e debugging

🎨 DESIGN E CRIATIVIDADE:
- Criar layouts responsivos e modernos
- Sugerir paletas de cores e tipografias
- Gerar wireframes em código
- Criar animações CSS/JS

📝 ESCRITA E CONTEÚDO:
- Redação profissional e criativa
- Tradução multilíngue
- Documentação técnica
- SEO e marketing de conteúdo

🧠 INTELIGÊNCIA:
- Resolução de problemas complexos
- Planejamento de projetos
- Consultoria técnica e de negócios
- Tutoriais passo a passo

REGRAS DE FORMATAÇÃO:
1. Sempre use markdown para formatar respostas
2. Para código, SEMPRE especifique a linguagem no bloco de código
3. Quando gerar projetos com múltiplos arquivos, use o formato:
   \`\`\`linguagem:caminho/do/arquivo.ext
   conteúdo do arquivo
   \`\`\`
   Isso permite que o usuário baixe todos os arquivos como ZIP.
4. Seja detalhado e completo - não abrevie código
5. Responda no idioma do usuário
6. Use emojis moderadamente para melhorar a legibilidade
7. Para projetos grandes, organize por arquivos e explique a estrutura`;

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          ...messages,
        ],
        stream: true,
        max_tokens: 16384,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded" }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required" }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("nexo-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
